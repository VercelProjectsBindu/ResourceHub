/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Hero from './components/hero/Hero';
import Projects from './components/projects/Projects';
import Capabilities from './components/capabilities/Capabilities';
import Footer from './components/footer/Footer';
import BackToTop from './components/ui/BackToTop';

export default function App() {
  return (
    <div className="min-h-screen selection:bg-primary/30">
      <Hero />
      <Capabilities />
      <Projects />
      <Footer />
      <BackToTop />
    </div>
  );
}
